/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _EMU_INC_HASH_MD4_H
#define _EMU_INC_HASH_MD4_H

#include "emu_general.h"

#include "inc_vendor.h"
#include "inc_hash_md4.h"

#endif // _EMU_INC_HASH_MD4_H
