/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _EMU_INC_RP_H
#define _EMU_INC_RP_H

#include "emu_general.h"

#include "inc_vendor.h"
#include "inc_rp.h"

#endif // _EMU_INC_RP_H
