/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _EMU_INC_ECC_SECP256K1_H
#define _EMU_INC_ECC_SECP256K1_H

#include "emu_general.h"

#include "inc_vendor.h"
#include "inc_ecc_secp256k1.h"

#endif // _EMU_INC_ECC_SECP256K1_H
